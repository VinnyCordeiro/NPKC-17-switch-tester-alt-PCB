#ifndef PROCESS_PRINTER_H
#define PROCESS_PRINTER_H

#include "quantum.h"

#include "protocol/serial.h"

#endif